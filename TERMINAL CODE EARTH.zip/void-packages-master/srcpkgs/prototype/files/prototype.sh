#!/bin/sh
cd /usr/libexec/prototype
exec ./prototype "$@"
