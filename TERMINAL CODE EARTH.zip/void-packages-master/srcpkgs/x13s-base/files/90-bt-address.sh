msg "Setting bluetooth MAC address..."
/usr/libexec/x13s-setup bluetooth
