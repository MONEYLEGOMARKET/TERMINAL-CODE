#!/bin/sh
exec /usr/bin/cc -std=c99 "$@"
