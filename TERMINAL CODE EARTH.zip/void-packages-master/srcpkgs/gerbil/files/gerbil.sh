export GERBIL_GSC=gambit-gsc
export GERBIL_HOME=/usr/lib/gerbil

