msg "Bringing up the network..."
mkdir -p /run/network
ifup -a
