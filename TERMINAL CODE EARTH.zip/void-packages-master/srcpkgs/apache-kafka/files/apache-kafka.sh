#!/bin/sh

export PATH=$PATH:/usr/lib/kafka/bin
