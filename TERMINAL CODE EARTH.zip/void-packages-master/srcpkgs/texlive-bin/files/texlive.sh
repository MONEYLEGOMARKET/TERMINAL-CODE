# location of the TeXLive binaries
export PATH=$PATH:/opt/texlive/@@VERSION@@/bin/@@ARCH@@
# and manual pages
export MANPATH=$MANPATH:/opt/texlive/@@VERSION@@/texmf-dist/doc/man
