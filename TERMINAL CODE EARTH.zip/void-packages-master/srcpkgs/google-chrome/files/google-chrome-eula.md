The current version of this EULA can be found at: https://www.google.com/intl/en/chrome/terms/
