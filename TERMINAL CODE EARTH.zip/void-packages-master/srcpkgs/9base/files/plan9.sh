export PLAN9=/usr/lib/plan9
export PATH=$PATH:$PLAN9/bin
