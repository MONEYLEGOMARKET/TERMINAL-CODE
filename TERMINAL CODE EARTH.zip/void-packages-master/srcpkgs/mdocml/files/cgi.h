#define SCRIPT_NAME ""
#define MAN_DIR "/var/lib/man-cgi"
#define CSS_DIR ""
#define CUSTOMIZE_TITLE "Void Linux manpages"
#define COMPAT_OLDURI No
