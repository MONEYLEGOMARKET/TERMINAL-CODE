#!/bin/sh
java -jar /usr/lib/freerouting/freerouting-executable.jar "$@"
exit 0
