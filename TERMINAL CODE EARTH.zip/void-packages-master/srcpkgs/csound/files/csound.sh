export OPCODE6DIR=/usr/lib/csound/plugins64
export CSSTRNGS=/usr/share/locale
export RAWWAVE_PATH=/usr/lib/stk/rawwaves