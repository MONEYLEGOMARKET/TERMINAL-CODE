#ifndef __GLIBC__

/* sys/cdefs.h stubs for musl */

#ifndef __BEGIN_DECLS
#define __BEGIN_DECLS
#define __END_DECLS
#endif

#define __ASMNAME(x) "" x

#include <sys/types.h>
#endif
