export CABAL_DIR=/home/cabal
