#
# Sets the fetch_cmd variable used by hooks/do-fetch/00-distfiles.sh
#
: ${fetch_cmd:=$XBPS_FETCH_CMD}
