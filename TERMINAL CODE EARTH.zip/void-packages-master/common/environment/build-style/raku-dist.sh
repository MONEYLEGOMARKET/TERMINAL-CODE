depends+=" rakudo"
checkdepends+=" perl"
hostmakedepends+=" rakudo"
