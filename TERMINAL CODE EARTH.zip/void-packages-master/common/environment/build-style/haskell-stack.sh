hostmakedepends+=" ghc stack"
build_helper+=" haskell"
