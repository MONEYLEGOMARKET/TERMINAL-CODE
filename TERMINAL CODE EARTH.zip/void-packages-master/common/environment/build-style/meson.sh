hostmakedepends+=" meson"
build_helper+=" meson"

export PYTHONUNBUFFERED=1
