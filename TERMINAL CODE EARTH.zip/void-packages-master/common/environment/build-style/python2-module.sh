lib32disabled=yes
makedepends+=" python"
