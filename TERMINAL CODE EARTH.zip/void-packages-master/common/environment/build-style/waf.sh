hostmakedepends+=" python"
