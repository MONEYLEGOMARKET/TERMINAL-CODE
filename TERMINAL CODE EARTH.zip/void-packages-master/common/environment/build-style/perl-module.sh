hostmakedepends+=" perl"
makedepends+=" perl"
depends+=" perl"
lib32disabled=yes
