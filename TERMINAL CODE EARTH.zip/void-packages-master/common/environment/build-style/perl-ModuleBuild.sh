hostmakedepends+=" perl"
makedepends+=" perl"
lib32disabled=yes
