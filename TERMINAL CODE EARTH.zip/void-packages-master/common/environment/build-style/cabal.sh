hostmakedepends+=" cabal-install git"
build_helper+=" haskell"
