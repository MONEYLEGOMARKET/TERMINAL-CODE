hostmakedepends+=" scons"
