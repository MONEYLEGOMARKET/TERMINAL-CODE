hostmakedepends+=" python3"
