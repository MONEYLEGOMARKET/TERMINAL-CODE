lib32disabled=yes
hostmakedepends+=" ruby-devel"
makedepends+=" ruby-devel"
