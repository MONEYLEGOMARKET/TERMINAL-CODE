#!/bin/sh

echo "strip-wrapper: ignoring arguments: $@"
exit 0
